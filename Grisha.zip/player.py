import pygame.event
from pygame.sprite import Sprite

from animation2 import Animation


class Player(Sprite):
    def __init__(self):                         #-_-
        super().__init__()
        self.anims = {
            'down':Animation('anims/down/'),
            'right':Animation('anims/right/'),                  #-_-
            'up':Animation('anims/up/'),
            'left':Animation('anims/left/'),
            #'idle':Animation('anims/idle/'),
        }
        self.image = self.anims['down'].image
        self.rect = self.image.get_rect()
        self.current_anim = 'down'                              #-_-
        self.anim = self.anims[self.current_anim]
    def update(self,events,keys):
        for event in events:
            if event.type == pygame.KEYDOWN:                    #-_-
                if event.key == pygame.K_w:
                    self.current_anim = 'up'
                if event.key == pygame.K_s:
                    self.current_anim = 'down'
                if event.key == pygame.K_a:
                    self.current_anim = 'left'                          #-_-
                if event.key == pygame.K_d:
                     self.current_anim = 'right'
        self.anim = self.anims[self.current_anim]
                                                    #-_-
        self.anim.update()
        self.image = self.anim.image

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#
        x,y=self.rect.center
        if keys[pygame.K_a]:
            x-=10
        if keys[pygame.K_d]:
            x+=10
        if keys[pygame.K_w]:
            y -= 10
        if keys[pygame.K_s]:
            y += 10
        self.rect = self.image.get_rect(center=(x,y))

    def draw(self,screen):
        screen.blit(self.image,self.rect)

class App:                                                              #-_-
    def __init__(self):
        self.screen = pygame.display.set_mode((1000,700))
        self.clock = pygame.time.Clock()                                            #-_-
        self.player = Player()

    def run(self):
        running=True
        while running:                                                              #-_-
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    running=False
            keys = pygame.key.get_pressed()
            self.player.update(events, keys)
            self.screen.fill(pygame.color.Color('white')) #MediumVioletRed
            self.player.draw(self.screen)
            pygame.display.flip()
            self.clock.tick(15)

if __name__ == "__main__":
    app = App()
    app.run()